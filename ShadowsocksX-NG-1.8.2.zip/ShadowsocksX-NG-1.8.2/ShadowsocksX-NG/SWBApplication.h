//
// Created by clowwindy on 3/1/14.
// Copyright (c) 2014 clowwindy. All rights reserved.
//

#import <Foundation/Foundation.h>
@import AppKit;


@interface SWBApplication : NSApplication
@end