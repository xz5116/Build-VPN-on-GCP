//
//  main.m
//  LaunchHelper
//
//  Created by 邱宇舟 on 2017/3/28.
//  Copyright © 2017年 qiuyuzhou. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
